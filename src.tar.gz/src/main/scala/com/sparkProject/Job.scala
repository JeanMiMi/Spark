package com.sparkProject

import org.apache.spark.sql.SparkSession

object Job {

  def main(args: Array[String]): Unit = {

    // SparkSession configuration
    val spark = SparkSession
      .builder
      .appName("spark session TP_parisTech")
      .getOrCreate()

    val sc = spark.sparkContext

    import spark.implicits._


    /********************************************************************************
      *
      *        TP 1
      *
      *        - Set environment, InteliJ, submit jobs to Spark
      *        - Load local unstructured data
      *        - Word count , Map Reduce
      ********************************************************************************/



    // ----------------- word count ------------------------

    val df_wordCount = sc.textFile("/home/jean-michel/Desktop/Spark/spark-2.0.0-bin-hadoop2.7/README.md")
      .flatMap{case (line: String) => line.split(" ")}
      .map{case (word: String) => (word, 1)}
      .reduceByKey{case (i: Int, j: Int) => i + j}
      .toDF("word", "count")

    df_wordCount.orderBy($"count".desc).show()


    /********************************************************************************
      *
      *        TP 2 : début du projet
      *
      ********************************************************************************/

    val df = spark.read.option("header", true).option("inferSchema", true).option("comment", "#")
      .csv("/home/jean-michel/Desktop/cumulative.csv")

    println("Number of columns", df.columns.length)
    println("Number of rows", df.count)


    import org.apache.spark.sql.functions._
    val columns = df.columns.slice(10,20)
    df.select(columns.map(col):_*).show(50)


    df.groupBy("koi_disposition").count().show()


    val df2 = df.filter(not($"koi_disposition" === "CANDIDATE"))
    df2.groupBy("koi_disposition").count().show()

    df2.groupBy("koi_eccen_err1").count().show()

    val df3 = df2.drop($"koi_eccen_err1")

    val df4 = df3.drop("index", "kepid", "koi_fpflag_nt", "koi_fpflag_ss", "koi_fpflag_co", "koi_fpflag_ec", "koi_sparprov", "koi_trans_mod", "koi_datalink_dvr", "koi_datalink_dvs", "koi_tce_delivname", "koi_parm_prov", "koi_limbdark_mod", "koi_fittype", "koi_disp_prov", "koi_comment", "kepoi_name", "kepler_name", "koi_vet_date", "koi_pdisposition")



    //df4.select($"rowid").distinct().show()
    //df4.select($"koi_disposition").distinct().show()
    //df4.select($"koi_vet_stat").distinct().show()   --> kill
    //df4.select($"koi_period").distinct().show()
    //df4.select($"koi_period_err1").distinct().show()
    //df4.select($"koi_period_err2").distinct().show()
    //df4.select($"koi_time0bk").distinct().show()
    //df4.select($"koi_time0bk_err1").distinct().show()
    //df4.select($"koi_time0bk_err2").distinct().show()
    //df4.select($"koi_time0").distinct().show()
    //df4.select($"koi_time0_err1").distinct().show()
    //df4.select($"koi_time0_err2").distinct().show()
    //df4.select($"koi_eccen").distinct().show()  --> kill


    val df5 = df4.drop($"koi_vet_stat")
    val df6 = df5.drop($"koi_eccen")

    // df6.printSchema()

    val useless_column = df6.columns.filter{case(column:String)=> df6.agg(countDistinct(column)).first().getLong(0) <= 1}

    val df7 = df6.drop(useless_column: _*)

    df7.describe("koi_impact", "koi_duration").show()

    val df_filled = df7.na.fill(0.0)

    val df_labels = df_filled.select("rowid", "koi_disposition")
    val df_features = df_filled.drop("koi_disposition")

    val df_joined = df_features
      .join(df_labels, usingColumn = "rowid")


    def udf_sum = udf((col1: Double, col2: Double) => col1 + col2)


    val df_newFeatures = df_filled
      .withColumn("koi_ror_min", udf_sum($"koi_ror", $"koi_ror_err2"))
      .withColumn("koi_ror_max", $"koi_ror" + $"koi_ror_err1")

    df_newFeatures
      .coalesce(1) // optional : regroup all data in ONE partition, so that results are printed in ONE file
      // >>>> You should  not do that in general, only when the data are small enough to fit in the memory of a single machine.
      .write
      .mode("overwrite")
      .option("header", true)
      .csv("/home/jean-michel/Desktop/Spark/spark-2.0.0-bin-hadoop2.7/cleanedDataFrame.csv")

















  }


}
